module.exports = {
  cookieSecret: 'your secret here',
};
