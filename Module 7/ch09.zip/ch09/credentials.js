module.exports = {
  cookieSecret: 'coming strength nothing half',
}
